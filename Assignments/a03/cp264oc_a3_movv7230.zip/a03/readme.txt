Name: Vikas Movva
ID: 190957230
Email: movv7230@mylaurier.ca
WorkID: cp264oc-a3
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Question_ID [self-evaluation/total/marker-evaluation] Description

Lab3

T1 Strings
T1.1 [2/2/*] Read and test string examples
T2 Structures
T2.1 [2/2/*] Read and test structure examples
T3 Union
T3.1 [1/1/*] Read and test union examples
T4 Enumeration
T4.1 [1/1/*] Read and test enum examples
T5 File I/O
T5.1 [2/2/*] ASCII/text file I/O
T5.2 [1/1/*] Binary file I/O
T5.3 [1/1/*] CSV file I/O

A3

Q1 My string functions
Q1.1 [3/3/*] str_length()                            
Q1.2 [3/3/*] word_count()                            
Q1.3 [3/3/*] lower_case()                            
Q1.4 [3/3/*] trim()                                  
Q2 My word processor
Q2.1 [0/3/*] Data structure for stop words           
Q2.2 [0/3/*] set_stopword()                          
Q2.3 [0/3/*] contain_word()                          
Q2.4 [0/3/*] str_contain_word()                      
Q2.5 [0/3/*] process_word(()                         
Q2.6 [0/3/*] save_to_file()                          

Total: [0/40/*]

Copy and paste the console output of your public test in the following. This will help markers to evaluate your program if it fails the marking testing.  

Q1 output:


Q2 output:



